#include "xparameters.h"
#include "xgpio.h"
#include "xscugic.h"
#include "xil_exception.h"
#include "xil_printf.h"

// Định nghĩa các ID phần cứng (lấy từ xparameters.h)
#define INTC_DEVICE_ID 		    XPAR_PS7_SCUGIC_0_DEVICE_ID
#define BTNS_DEVICE_ID		    XPAR_AXI_GPIO_0_DEVICE_ID
#define LEDS_DEVICE_ID		    XPAR_AXI_GPIO_1_DEVICE_ID
#define INTC_GPIO_INTERRUPT_ID  XPAR_FABRIC_AXI_GPIO_0_IP2INTC_IRPT_INTR
#define BTN_INT 			    XGPIO_IR_CH1_MASK

// Khai báo các biến toàn cục cho thiết bị
XGpio LEDInst, BTNInst;
XScuGic INTCInst;

// Biến lưu trữ giá trị đếm để hiển thị ra LED
static int led_data = 0;

//----------------------------------------------------
// HÀM XỬ LÝ NGẮT (INTERRUPT HANDLER)
// Hàm này sẽ tự động được gọi mỗi khi có nút bấm được nhấn
//----------------------------------------------------
void BTN_Intr_Handler(void *InstancePtr)
{
    // 1. Tắt ngắt tạm thời để tránh bị ngắt đè khi đang xử lý
    XGpio_InterruptDisable(&BTNInst, BTN_INT);

    // 2. Bỏ qua nếu ngắt không thực sự xảy ra
    if ((XGpio_InterruptGetStatus(&BTNInst) & BTN_INT) != BTN_INT) {
        return;
    }

    // 3. Đọc giá trị của nút bấm (nút nào đang được nhấn)
    int btn_value = XGpio_DiscreteRead(&BTNInst, 1);

    // 4. Nếu có nút được nhấn, cộng giá trị nút vào biến đếm và xuất ra LED
    if(btn_value != 0) {
        led_data = led_data + btn_value;
        XGpio_DiscreteWrite(&LEDInst, 1, led_data);
    }

    // 5. Xóa cờ ngắt để hệ thống biết đã xử lý xong
    (void)XGpio_InterruptClear(&BTNInst, BTN_INT);

    // 6. Bật lại ngắt để chờ lần bấm tiếp theo
    XGpio_InterruptEnable(&BTNInst, BTN_INT);
}

//----------------------------------------------------
// HÀM CẤU HÌNH HỆ THỐNG NGẮT
// Thiết lập kết nối giữa Hardware (Nút bấm) và Software (Hàm xử lý)
//----------------------------------------------------
int InterruptSystemSetup(XScuGic *XScuGicInstancePtr)
{
    XScuGic_Config *IntcConfig;

    // Khởi tạo bộ điều khiển ngắt (ScuGic)
    IntcConfig = XScuGic_LookupConfig(INTC_DEVICE_ID);
    XScuGic_CfgInitialize(XScuGicInstancePtr, IntcConfig, IntcConfig->CpuBaseAddress);

    // Khởi tạo và đăng ký hệ thống ngoại lệ (Exception) của ARM Cortex-A9
    Xil_ExceptionInit();
    Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,
                                 (Xil_ExceptionHandler)XScuGic_InterruptHandler,
                                 XScuGicInstancePtr);

    // KẾT NỐI: Liên kết tín hiệu ngắt phần cứng với hàm BTN_Intr_Handler
    XScuGic_Connect(XScuGicInstancePtr, INTC_GPIO_INTERRUPT_ID,
                    (Xil_ExceptionHandler)BTN_Intr_Handler,
                    (void *)&BTNInst);

    // Kích hoạt ngắt trên GPIO và trên bộ điều khiển ngắt
    XGpio_InterruptEnable(&BTNInst, BTN_INT);
        XGpio_InterruptGlobalEnable(&BTNInst);
        XScuGic_Enable(XScuGicInstancePtr, INTC_GPIO_INTERRUPT_ID);
        Xil_ExceptionEnable();

        return XST_SUCCESS;
    }

    //----------------------------------------------------
    // CHƯƠNG TRÌNH CHÍNH
    //----------------------------------------------------
    int main (void)
    {
        // Khởi tạo GPIO cho LED (Output)
        XGpio_Initialize(&LEDInst, LEDS_DEVICE_ID);
        XGpio_SetDataDirection(&LEDInst, 1, 0x00); // 0x00 = Output

        // Khởi tạo GPIO cho Nút bấm (Input)
        XGpio_Initialize(&BTNInst, BTNS_DEVICE_ID);
        XGpio_SetDataDirection(&BTNInst, 1, 0xFF); // 0xFF = Input

        // Gọi hàm cài đặt hệ thống ngắt
        InterruptSystemSetup(&INTCInst);

        // Vòng lặp vô hạn: Vi xử lý "ngủ" và chờ phần cứng gọi dậy thông qua ngắt
        while(1) {
        }

        return 0;
    }
